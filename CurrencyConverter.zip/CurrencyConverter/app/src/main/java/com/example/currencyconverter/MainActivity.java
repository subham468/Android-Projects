package com.example.currencyconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.Formatter;

public class MainActivity extends AppCompatActivity {
    Button euro, pound, dollar, yen, dinar, bitcoin, rubel, ausdollar, candollar;
    EditText editText;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        euro = findViewById(R.id.euro);
        dollar = findViewById(R.id.dollar);
        pound = findViewById(R.id.pound);
        yen = findViewById(R.id.yen);
        dinar = findViewById(R.id.kuwaitDinar);
        bitcoin = findViewById(R.id.bitcoin);
        rubel = findViewById(R.id.russiaRuble);
        ausdollar = findViewById(R.id.ausDollar);
        candollar = findViewById(R.id.canDollar);
        editText= findViewById(R.id.editText2);
        textView = findViewById(R.id.textView);
    }

    public void euro(View view) {
        String z = editText.getText().toString();
        if(TextUtils.isEmpty(z)){
            editText.setError("Empty User Input");
        }
        else{
           double n,e;
            n = Double.parseDouble(z);
            textView.setText(null);
//                    Formatter formatter = new Formatter();
            e = n * 0.013;
            DecimalFormat numberFormat = new DecimalFormat("#.00");
            textView.setText(""+numberFormat.format(e));
        }
    }


    public void dollar(View view) {
        String z = editText.getText().toString();
        if(TextUtils.isEmpty(z)){
            editText.setError("Empty User Input");
        }
        else{
            double n,d;
            n = Double.parseDouble(z);
            textView.setText(null);
//                    Formatter formatter = new Formatter();
            d = n * 0.014;
            DecimalFormat numberFormat = new DecimalFormat("#.00");
            textView.setText(""+numberFormat.format(d));
        }
    }

    public void pound(View view) {
        String z = editText.getText().toString();
        if(TextUtils.isEmpty(z)){
            editText.setError("Empty User Input");
        }
        else{
            double n,e;
            n = Double.parseDouble(z);
            textView.setText(null);
//                    Formatter formatter = new Formatter();
            e = n * 0.011;
            DecimalFormat numberFormat = new DecimalFormat("#.00");
            textView.setText(""+numberFormat.format(e));
        }
    }

    public void yen(View view) {
        String z = editText.getText().toString();
        if(TextUtils.isEmpty(z)){
            editText.setError("Empty User Input");
        }
        else{
            double n,e;
            n = Double.parseDouble(z);
            textView.setText(null);
//                    Formatter formatter = new Formatter();
            e = n * 1.51;
            DecimalFormat numberFormat = new DecimalFormat("#.00");
            textView.setText(""+numberFormat.format(e));
        }
    }

    public void dinar(View view) {
        String z = editText.getText().toString();
        if(TextUtils.isEmpty(z)){
            editText.setError("Empty User Input");
        }
        else{
            double n,e;
            n = Double.parseDouble(z);
            textView.setText(null);
//                    Formatter formatter = new Formatter();
            e = n * 0.0042;
            DecimalFormat numberFormat = new DecimalFormat("#.00");
            textView.setText(""+numberFormat.format(e));
        }
    }

    public void peso(View view) {
        String z = editText.getText().toString();
        if(TextUtils.isEmpty(z)){
            editText.setError("Empty User Input");
        }
        else{
            double n,e;
            n = Double.parseDouble(z);
            textView.setText(null);
//                    Formatter formatter = new Formatter();
            e = n * 0.71;
            DecimalFormat numberFormat = new DecimalFormat("#.00");
            textView.setText(""+numberFormat.format(e));
        }
    }

    public void ruble(View view) {
        String z = editText.getText().toString();
        if(TextUtils.isEmpty(z)){
            editText.setError("Empty User Input");
        }
        else{
            double n,e;
            n = Double.parseDouble(z);
            textView.setText(null);
//                    Formatter formatter = new Formatter();
            e = n * 0.89;
            DecimalFormat numberFormat = new DecimalFormat("#.00");
            textView.setText(""+numberFormat.format(e));
        }
    }

    public void ausdollar(View view) {
        String z = editText.getText().toString();
        if(TextUtils.isEmpty(z)){
            editText.setError("Empty User Input");
        }
        else{
            double n,e;
            n = Double.parseDouble(z);
            textView.setText(null);
//                    Formatter formatter = new Formatter();
            e = n * 0.021;
            DecimalFormat numberFormat = new DecimalFormat("#.00");
            textView.setText(""+numberFormat.format(e));
        }
    }

    public void candollar(View view) {
        String z = editText.getText().toString();
        if(TextUtils.isEmpty(z)){
            editText.setError("Empty User Input");
        }
        else{
            double n,e;
            n = Double.parseDouble(z);
            textView.setText(null);
//                    Formatter formatter = new Formatter();
            e = n * 0.019;
            DecimalFormat numberFormat = new DecimalFormat("#.00");
            textView.setText(""+numberFormat.format(e));
        }
    }
}
